import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import JohnnyBot from '@/components/animation/JohnnyBot';
import ModeToggle from '@/components/chat/ModeToggle';
import MicButton from '@/components/chat/MicButton';
import { getAssistantMode, setAssistantMode, type AssistantMode } from '@/lib/settings';
import { sendChat, getFallbackResponse, type ChatMessage } from '@/lib/chatService';
import { sendUtterance } from '@/lib/lexUtterance';
import { sendChatStream } from '@/lib/chatApi';
import '@/lib/testApi'; // Import test function

export default function AWSChatBot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: "Hello! I'm Johnny-5, your AWS assistant. I can help you with cost optimization, security monitoring, and infrastructure insights. What would you like to know?",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [assistantMode, setAssistantModeState] = useState<AssistantMode>(getAssistantMode());
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  
  // Generate a unique session ID for Lex conversations
  const sessionId = useMemo(() => crypto.randomUUID(), []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Mode change handler with persistence
  const changeMode = (mode: AssistantMode) => {
    setAssistantModeState(mode);
    setAssistantMode(mode); // persist choice
  };

  const playAudio = (audioUrl: string) => {
    if (audioRef.current) {
      audioRef.current.src = audioUrl;
      audioRef.current.play().catch(console.error);
      setIsPlayingAudio(true);
    }
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlayingAudio(false);
    }
  };

  // Handle mic capture for Lex modes
  const handleMicCapture = async (blob: Blob) => {
    // Only process mic input for Lex modes
    if (assistantMode === 'bedrock') return;
    
    setIsTyping(true);
    
    // Add voice message indicator
    const voiceMessage: ChatMessage = {
      id: Date.now().toString(),
      text: "(voice message...)",
      sender: 'user',
      timestamp: new Date()
    };
    setMessages(prev => [...prev, voiceMessage]);

    try {
      const { text, audioBlob } = await sendUtterance(blob, sessionId);
      
      const botResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: text,
        sender: 'bot',
        timestamp: new Date(),
        audioUrl: audioBlob ? URL.createObjectURL(audioBlob) : undefined
      };
      
      setMessages(prev => [...prev, botResponse]);
      
      // Auto-play audio if available
      if (audioBlob) {
        const url = URL.createObjectURL(audioBlob);
        const audio = new Audio(url);
        await audio.play();
        setTimeout(() => URL.revokeObjectURL(url), 15000);
      }
      
    } catch (error) {
      console.error('Error processing voice message:', error);
      const errorResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: "I'm having trouble processing your voice message. Please try again.",
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputText;
    setInputText('');
    setIsTyping(true);

    try {
      let botResponseText: string;
      let audioUrl: string | undefined;

      switch (assistantMode) {
        case 'bedrock':
          // Direct Bedrock integration via API with streaming
          try {
            console.log('Bedrock mode - Starting request...');
            
            const streamingMessageId = (Date.now() + 1).toString();
            
            // Create initial empty bot message for streaming
            const initialBotMessage: ChatMessage = {
              id: streamingMessageId,
              text: "",
              sender: 'bot',
              timestamp: new Date()
            };
            setMessages(prev => [...prev, initialBotMessage]);
            
            // Stream the response
            try {
              console.log('Starting streaming request...');
              let hasReceivedData = false;
              
              for await (const chunk of sendChatStream({
                message: currentInput,
                mode: 'bedrock',
                sessionId: crypto.randomUUID()
              })) {
                hasReceivedData = true;
                console.log('Received chunk:', chunk);
                
                // Update the streaming message
                setMessages(prev => {
                  const updated = [...prev];
                  const streamingMessage = updated.find(msg => msg.id === streamingMessageId);
                  if (streamingMessage) {
                    streamingMessage.text += chunk;
                  }
                  return updated;
                });
              }
              
              if (!hasReceivedData) {
                console.log('No data received from streaming, trying fallback...');
                throw new Error('No streaming data received');
              }
              
              botResponseText = ""; // Already handled by streaming
            } catch (streamError) {
              console.log('Streaming failed, trying fallback:', streamError);
              
              // Fallback to regular API call
              const response = await sendChat(currentInput, 'bedrock');
              console.log('Fallback response:', response);
              
              botResponseText = response.message;
              audioUrl = response.audioUrl;
              
              // Update the streaming message with the fallback response
              setMessages(prev => {
                const updated = [...prev];
                const streamingMessage = updated.find(msg => msg.id === streamingMessageId);
                if (streamingMessage) {
                  streamingMessage.text = botResponseText;
                }
                return updated;
              });
            }
          } catch (error) {
            console.error('Chat API error:', error);
            botResponseText = getFallbackResponse(currentInput);
          }
          break;
          
        case 'lex':
          // Lex + Bedrock (text only)
          try {
            const response = await sendChat(currentInput, 'lex');
            botResponseText = response.message;
          } catch (error) {
            console.error('Lex API error:', error);
            botResponseText = getFallbackResponse(currentInput);
          }
          break;
          
        case 'lex+voice':
          // Lex + Bedrock + Polly (voice)
          try {
            const response = await sendChat(currentInput, 'lex+voice');
            botResponseText = response.message;
            audioUrl = response.audioUrl;
          } catch (error) {
            console.error('Lex+Voice API error:', error);
            botResponseText = getFallbackResponse(currentInput);
          }
          break;
          
        default:
          botResponseText = getFallbackResponse(currentInput);
      }

      // Only add bot response if we didn't handle it via streaming
      if (botResponseText && assistantMode !== 'bedrock') {
        const botResponse: ChatMessage = {
          id: (Date.now() + 1).toString(),
          text: botResponseText,
          sender: 'bot',
          timestamp: new Date(),
          audioUrl
        };
        setMessages(prev => [...prev, botResponse]);
      } else if (assistantMode === 'bedrock' && !botResponseText) {
        // Handle error case for bedrock mode
        const errorResponse: ChatMessage = {
          id: (Date.now() + 1).toString(),
          text: getFallbackResponse(currentInput),
          sender: 'bot',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, errorResponse]);
      }
      
      // Auto-play audio if available
      if (audioUrl && assistantMode === 'lex+voice') {
        setTimeout(() => playAudio(audioUrl), 500);
      }
      
    } catch (error) {
      console.error('Error processing message:', error);
      const errorResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: "I'm having trouble processing your request right now. Please try again.",
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setIsTyping(false);
    }
  };


  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="p-8 min-h-[500px] flex flex-col">
      <div className="text-center mb-6">
        <JohnnyBot className="mx-auto mb-4" />
        <h3 className="text-xl font-semibold mb-2">How can I help?</h3>
        <p className="text-jc-dim text-sm mb-4">
          Ask me anything about your AWS infrastructure
        </p>
        
        {/* Assistant Mode Switch */}
        <div className="bg-black/20 rounded-lg p-4 mb-6">
          <div className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <span>🤖</span>
            Choose Assistant Mode
          </div>
          <ModeToggle mode={assistantMode} onChange={changeMode} />
          
          {/* Debug button */}
          <div className="mt-3">
            <button 
              onClick={() => (window as any).testChatApi?.()}
              className="text-xs text-jc-dim hover:text-white underline"
            >
              Test API Connection
            </button>
          </div>
          
          {/* Current Mode Description */}
          <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/10">
            <div className="text-sm font-medium text-white mb-1">
              {assistantMode === 'bedrock' && '💬 Text Only Mode'}
              {assistantMode === 'lex' && '🤖 Lex + Text Mode'}
              {assistantMode === 'lex+voice' && '🎤 Lex + Voice Mode'}
            </div>
            <div className="text-xs text-jc-dim">
              {assistantMode === 'bedrock' && 'Direct Bedrock integration via API. Fast text responses.'}
              {assistantMode === 'lex' && 'Lex recognizes intent, Bedrock generates response. Better context understanding.'}
              {assistantMode === 'lex+voice' && 'Lex + Bedrock + voice synthesis. Full conversational experience with audio.'}
            </div>
            {(assistantMode === 'lex' || assistantMode === 'lex+voice') && (
              <div className="text-xs text-jc-cyan mt-2 flex items-center gap-1">
                <span>🎤</span>
                <span>Hold the mic button to talk, release to send</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Chat Messages Area */}
      <div className="flex-1 bg-black/20 rounded-lg p-4 mb-4 space-y-3 min-h-[200px] max-h-[300px] overflow-y-auto">
        {messages.map((message) => (
          <div key={message.id} className={`flex items-start gap-3 ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              message.sender === 'bot' ? 'bg-jc-cyan/20' : 'bg-jc-green/20'
            }`}>
              <span className={`text-xs font-bold ${
                message.sender === 'bot' ? 'text-jc-cyan' : 'text-jc-green'
              }`}>
                {message.sender === 'bot' ? 'J5' : 'U'}
              </span>
            </div>
            <div className={`max-w-[80%] ${message.sender === 'user' ? 'text-right' : ''}`}>
              <div className={`rounded-lg p-3 ${
                message.sender === 'bot' ? 'bg-white/5' : 'bg-jc-cyan/10'
              }`}>
                {/* Key style: preserves newlines & bullets */}
                <div className="whitespace-pre-wrap break-words text-white/90 text-sm">
                  {message.text || "[no content]"}
                </div>
                {message.audioUrl && message.sender === 'bot' && (
                  <div className="mt-2 flex items-center gap-2">
                    <button
                      onClick={() => isPlayingAudio ? stopAudio() : playAudio(message.audioUrl!)}
                      className="flex items-center gap-1 px-2 py-1 bg-jc-cyan/20 text-jc-cyan rounded text-xs hover:bg-jc-cyan/30 transition-colors"
                    >
                      {isPlayingAudio ? (
                        <>
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/>
                          </svg>
                          Stop
                        </>
                      ) : (
                        <>
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z"/>
                          </svg>
                          Play
                        </>
                      )}
                    </button>
                    <span className="text-xs text-jc-dim">Voice response</span>
                  </div>
                )}
              </div>
              <div className={`text-xs text-jc-dim mt-1 ${
                message.sender === 'user' ? 'text-right' : 'text-left'
              }`}>
                {message.timestamp.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-jc-cyan/20 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-jc-cyan text-xs font-bold">J5</span>
            </div>
            <div className="bg-white/5 rounded-lg p-3">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-jc-cyan rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-jc-cyan rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-jc-cyan rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask Johnny-5 anything..."
          className="flex-1 bg-white/5 border border-white/10 rounded-lg p-3 focus-glow text-white placeholder-jc-dim"
          disabled={isTyping}
        />
        {/* Show mic button for Lex modes */}
        {(assistantMode === 'lex' || assistantMode === 'lex+voice') && (
          <MicButton 
            onCapture={handleMicCapture} 
            disabled={isTyping}
          />
        )}
        <Button 
          onClick={handleSendMessage} 
          className="px-4"
          disabled={!inputText.trim() || isTyping}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
          </svg>
        </Button>
      </div>
      
      {assistantMode === 'bedrock' && (
        <p className="text-xs text-jc-dim mt-2 flex items-center gap-1">
          <span>💡</span>
          <span>Switch to Lex mode above to enable voice input</span>
        </p>
      )}
      
      {/* Hidden audio element for voice playback */}
      <audio
        ref={audioRef}
        onEnded={() => setIsPlayingAudio(false)}
        onError={() => setIsPlayingAudio(false)}
      />
    </Card>
  );
}