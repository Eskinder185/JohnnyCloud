// src/lib/auth.ts
function base64Url(u8: Uint8Array) {
  return btoa(String.fromCharCode(...u8))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function sha256(input: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return base64Url(new Uint8Array(buf));
}

export async function startLogin() {
  try {
    console.log("startLogin: Starting authentication...");
    
    const codeVerifier = base64Url(crypto.getRandomValues(new Uint8Array(32)));
    sessionStorage.setItem("pkce_verifier", codeVerifier);
    console.log("startLogin: PKCE verifier generated and stored");

    const codeChallenge = await sha256(codeVerifier);
    console.log("startLogin: Code challenge generated");
    
    const domain   = import.meta.env.VITE_COGNITO_DOMAIN as string;
    const clientId = import.meta.env.VITE_COGNITO_CLIENT_ID as string;
    const redirect = `${window.location.origin}/auth/callback`;

    // Debug logging
    console.log("Auth Debug Info:");
    console.log("- Current origin:", window.location.origin);
    console.log("- Redirect URI:", redirect);
    console.log("- Cognito domain:", domain);
    console.log("- Client ID:", clientId);

    if (!domain || !clientId) {
      console.error("startLogin: Missing environment variables!");
      console.error("- Domain:", domain);
      console.error("- Client ID:", clientId);
      return;
    }

    const url = new URL(`${domain}/oauth2/authorize`);
    url.search = new URLSearchParams({
      client_id: clientId,
      response_type: "code",
      scope: "openid email phone",
      redirect_uri: redirect,
      code_challenge: codeChallenge,
      code_challenge_method: "S256",
    }).toString();

    console.log("Full auth URL:", url.toString());
    console.log("startLogin: Redirecting to Cognito...");
    window.location.href = url.toString();
  } catch (error) {
    console.error("startLogin: Error occurred:", error);
  }
}

export function signOut() {
  const domain   = import.meta.env.VITE_COGNITO_DOMAIN as string;
  const clientId = import.meta.env.VITE_COGNITO_CLIENT_ID as string;
  const logout   = `${domain}/logout?client_id=${clientId}&logout_uri=${encodeURIComponent(window.location.origin + "/")}`;

  localStorage.removeItem("id_token");
  localStorage.removeItem("access_token");
  window.location.href = logout;
}

export function getJwt() {
  // Prefer ID token (works with API GW JWT authorizer); fall back to access token
  return localStorage.getItem("id_token") || localStorage.getItem("access_token") || "";
}

export function isLoggedIn(): boolean {
  const token = getJwt();
  if (!token) return false;
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return Date.now() / 1000 < payload.exp;
  } catch { return false; }
}
