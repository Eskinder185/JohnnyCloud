// src/pages/AuthCallback.tsx
import { useEffect } from "react";

export default function AuthCallback() {
  useEffect(() => {
    (async () => {
      console.log("AuthCallback: Starting token exchange...");
      const code = new URLSearchParams(location.search).get("code");
      const verifier = sessionStorage.getItem("pkce_verifier");
      
      console.log("AuthCallback: Code:", code ? "present" : "missing");
      console.log("AuthCallback: Verifier:", verifier ? "present" : "missing");
      
      if (!code || !verifier) { 
        console.log("AuthCallback: Missing code or verifier, redirecting to home");
        location.replace("/"); 
        return; 
      }

      const domain   = import.meta.env.VITE_COGNITO_DOMAIN as string;
      const clientId = import.meta.env.VITE_COGNITO_CLIENT_ID as string;
      const redirect = `${window.location.origin}/auth/callback`;

      const body = new URLSearchParams({
        grant_type: "authorization_code",
        client_id: clientId,
        code,
        code_verifier: verifier,
        redirect_uri: redirect,
      });

      console.log("AuthCallback: Exchanging code for tokens...");
      const res = await fetch(`${domain}/oauth2/token`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body,
      });

      console.log("AuthCallback: Token response status:", res.status);
      
      if (!res.ok) {
        const errorText = await res.text();
        console.error("AuthCallback: Token exchange failed with status:", res.status);
        console.error("AuthCallback: Error response:", errorText);
        location.replace("/login");
        return;
      }
      
      const tokens = await res.json(); // {id_token, access_token, ...}
      console.log("AuthCallback: Received tokens:", Object.keys(tokens));
      
      if (!tokens.id_token && !tokens.access_token) {
        console.error("AuthCallback: No tokens in response:", tokens);
        location.replace("/login");
        return;
      }

      console.log("AuthCallback: Token exchange successful, storing tokens");
      if (tokens.id_token) localStorage.setItem("id_token", tokens.id_token);
      if (tokens.access_token) localStorage.setItem("access_token", tokens.access_token);

      sessionStorage.removeItem("pkce_verifier");
      console.log("AuthCallback: Redirecting to metrics...");
      location.replace("/metrics");
    })();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-jc-bg">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
        <p className="text-slate-300">Completing sign in...</p>
      </div>
    </div>
  );
}